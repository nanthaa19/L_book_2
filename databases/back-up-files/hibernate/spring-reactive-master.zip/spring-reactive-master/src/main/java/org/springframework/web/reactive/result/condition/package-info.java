/**
 * Support for mapping requests based on a
 * {@link org.springframework.web.reactive.result.condition.RequestCondition
 * RequestCondition} type hierarchy.
 */
package org.springframework.web.reactive.result.condition;
