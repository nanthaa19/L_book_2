/**
 * Defines Spring Web Reactive configuration.
 */
package org.springframework.web.reactive.config;
