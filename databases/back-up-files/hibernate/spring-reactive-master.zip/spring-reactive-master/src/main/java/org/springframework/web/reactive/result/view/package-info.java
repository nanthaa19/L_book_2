/**
 * Support for result handling through view resolution.
 */
package org.springframework.web.reactive.result.view;
