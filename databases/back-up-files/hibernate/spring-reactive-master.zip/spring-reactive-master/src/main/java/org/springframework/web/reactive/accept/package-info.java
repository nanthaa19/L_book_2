/**
 * This package provides support for various strategies to resolve the requested
 * content type for a given request.
 */
package org.springframework.web.reactive.accept;
