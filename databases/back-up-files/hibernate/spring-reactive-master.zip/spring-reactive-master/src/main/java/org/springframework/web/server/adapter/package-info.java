/**
 * Implementation support to adapt
 * {@link org.springframework.web.server Spring web server} to the underlying
 * {@link org.springframework.http.server.reactive HTTP server} layer.
 */
package org.springframework.web.server.adapter;
