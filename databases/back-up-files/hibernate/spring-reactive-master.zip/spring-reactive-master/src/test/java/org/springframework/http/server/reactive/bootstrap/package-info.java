/**
 * This package contains temporary interfaces and classes for running embedded servers.
 * They are expected to be replaced by an upcoming Spring Boot support.
 */
package org.springframework.http.server.reactive.bootstrap;
