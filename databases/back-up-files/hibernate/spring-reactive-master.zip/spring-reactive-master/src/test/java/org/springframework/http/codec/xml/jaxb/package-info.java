@javax.xml.bind.annotation.XmlSchema(namespace = "namespace")
package org.springframework.http.codec.xml.jaxb;
